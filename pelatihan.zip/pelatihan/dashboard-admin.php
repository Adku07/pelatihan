<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="script.js"></script>
    <div class="row" style="padding: 30px;">
        <!-- <div class="col">
            <button class="container p-3 rounded-2">
                <a href="Adminsarana.php" style="color:black">Admin edit tampilan 1</a>
            </button>
        </div>
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="Adminkurikulum.php" style="color:black">Admin Kurikulum</a>
            </button>
        </div> -->
        <!-- <div class="col">
            <button class="container p-3 rounded-2">
                <a href="#" style="color:black">Kelola akun</a>
            </button>
        </div> -->
    </div>

    <!-- <div class="row" style="padding: 20px">
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="#" style="color:black">Upload Tugas</a>
            </button>
        </div>
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="#" style="color:black">Upload Jurnal</a>
            </button>
        </div>
    </div> -->
    <div class="row" style="padding: 20px">
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="editcourse.php" style="color:black">Edit Course</a>
            </button>
        </div>
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="editabout.php" style="color:black">Edit About</a>
            </button>
        </div>
        <!-- <div class="col">
            <button class="container p-3 rounded-2">
                <a href="dataglr.php" style="color:black">Upload Galeri</a>
            </button>
        </div>
        <div class="col">
            <button class="container p-3 rounded-2">
                <a href="dataprest.php" style="color:black">Upload Prestasi</a>
            </button>
        </div> -->
    </div>
</body>
</html>